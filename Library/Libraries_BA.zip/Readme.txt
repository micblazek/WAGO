============================================================================
Bitte kopieren Sie die Bibliotheken aus der Datei "Libraries_BA.zip" in das Verzeichnis:

C:\Programme\WAGO Software\CoDeSys V2.3\Targets\WAGO\Libraries\Building
============================================================================


============================================================================
Please copy the libraries from file "Libraries_BA.zip" to folder:

C:\Program Files\WAGO Software\CoDeSys V2.3\Targets\WAGO\Libraries\Building
============================================================================